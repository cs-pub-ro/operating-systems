/*
 * copy-string-improved.c - copy string NUM_ROUNDS times using strcpy().
 *
 * Build and run:
 *     make
 *     ./copy-string-improved
 */

#include <stdio.h>
#include <string.h>
#include <time.h>

#define diff_us(ta, tb)		\
	(((ta).tv_sec - (tb).tv_sec) * 1000 * 1000 + \
	 ((ta).tv_nsec - (tb).tv_nsec) / 1000)

#define NUM_ROUNDS 100000000

static char big_string[1000];

int main(void)
{
	struct timespec time_before, time_after;

	clock_gettime(CLOCK_REALTIME, &time_before);
	/*
	 * TODO: Use strcpy() to copy the strings John, George, Paul, Joel.
	 * Use a loop going from 0 to NUM_ROUNDS.
	 */
	clock_gettime(CLOCK_REALTIME, &time_after);
	printf("time passed %ld microseconds\n", diff_us(time_after, time_before));

	return 0;
}
