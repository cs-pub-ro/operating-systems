/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef ON_COMMAND_H_
#define ON_COMMAND_H_	1

void do_map(unsigned int num_pages);

#endif
