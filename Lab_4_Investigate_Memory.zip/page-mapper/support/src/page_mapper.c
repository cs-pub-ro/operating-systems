// SPDX-License-Identifier: BSD-3-Clause

#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include "utils.h"
#include "page_mapper.h"


void do_map(unsigned int num_pages)
{
	/* TODO: Obtain page size. */

	/* TODO: Map pages in memory using mmap(). */
}
