// SPDX-License-Identifier: BSD-3-Clause

#include <stdio.h>
#include <unistd.h>

int main(void)
{
	puts("Hello, world!");
	sleep(10000);
	return 0;
}
