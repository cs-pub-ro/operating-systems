#!/bin/bash

dd if=/dev/urandom of=in.dat bs=1M count=32
