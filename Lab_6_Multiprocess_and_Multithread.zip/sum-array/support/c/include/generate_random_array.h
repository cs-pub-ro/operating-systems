/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef GENERATE_RANDOM_ARRAY
#define GENERATE_RANDOM_ARRAY

#define MAX_ELEMENT 1000

void generate_random_array(size_t length, int array[]);

#endif /* GENERATE_RANDOM_ARRAY */
