# printf() System Call

## Question Text

What system call does the `printf()` function invoke?

## Question Answers

- `read`

+ `write`

- `exec`

- `exit`

## Feedback

`printf()` invokes the `write` system call to print messages to standard output.
