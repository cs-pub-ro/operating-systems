#!/bin/bash

wget -O printf.c https://raw.githubusercontent.com/mpaland/printf/master/printf.c
wget -O printf.h https://raw.githubusercontent.com/mpaland/printf/master/printf.h
