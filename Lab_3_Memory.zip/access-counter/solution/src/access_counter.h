/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef ACCESS_PRINTER_H_
#define ACCESS_PRINTER_H_	1

extern unsigned long counter;
void register_sigsegv_handler(void);

#endif
